import requests
from bs4 import BeautifulSoup

# Define the URL of the Wikipedia page you want to scrape
url = "https://en.wikipedia.org/wiki/Alexander_the_Great"

# Send an HTTP GET request to the URL and retrieve the HTML content
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find all the headings and sub-headings (h1 to h6)
    headings = soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])

    # Find all the paragraphs containing text
    paragraphs = soup.find_all('p')

    # Create a dictionary to store the scraped data with headings as keys and content as values
    scraped_data = {}

    # Iterate through the headings and paragraphs and associate them
    current_heading = None
    for element in headings + paragraphs:
        if element.name.startswith('h'):  # Check if it's a heading
            current_heading = element.text.strip()
            scraped_data[current_heading] = []  # Initialize an empty list for content under this heading
        elif current_heading:
            scraped_data[current_heading].append(element.text.strip())

    # Print the scraped data for demonstration
    for heading, content in scraped_data.items():
        print(f"Heading: {heading}")
        print("\n".join(content))  # Join paragraphs with newlines

else:
    print(f"Failed to retrieve the page. Status code: {response.status_code}")
