import requests
from bs4 import BeautifulSoup
from nltk.tokenize import sent_tokenize
from transformers import BertTokenizer, BertModel
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import torch

# Define the Wikipedia page URL
url = "https://en.wikipedia.org/wiki/Alexander_the_Great"

# Send an HTTP GET request to the URL and retrieve the HTML content
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find all headings and their associated content
    sections = {}
    current_section = None

    for element in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p']):
        if element.name.startswith('h'):
            current_section = element.get_text()
            sections[current_section] = []
        elif current_section:
            sections[current_section].append(element.get_text())

    # Initialize BERT tokenizer and model
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    model = BertModel.from_pretrained('bert-base-uncased')

    # Initialize variables for quality metrics
    information_retention_scores = []
readability_scores = []
coherence_scores = []

# Function to extract embeddings from BERT
def get_bert_embeddings(text):
    tokens = tokenizer(text, return_tensors='pt', truncation=True, padding=True)
    with torch.no_grad():
        outputs = model(**tokens)
    embeddings = torch.mean(outputs.last_hidden_state, dim=1).squeeze()
    return embeddings.numpy()

# Summarize each section and evaluate quality metrics
for section, content in sections.items():
    # Combine content into a single string
    section_text = ' '.join(content)

    # Tokenize sentences in the section
    sentences = sent_tokenize(section_text)

    if not sentences:
        # Handle the case when there are no sentences to summarize
        continue

    # Get BERT embeddings for sentences
    sentence_embeddings = [get_bert_embeddings(sentence) for sentence in sentences]

    # Calculate pairwise cosine similarities
    cosine_similarities = cosine_similarity(sentence_embeddings)

    # Calculate the sentence importance score (sum of cosine similarities)
    sentence_importance_scores = np.sum(cosine_similarities, axis=1)

    # Sort sentences by importance
    sorted_sentences = [sentences[i] for i in np.argsort(sentence_importance_scores)[::-1]]

    # Create the summary by selecting the top sentences
    summary = ' '.join(sorted_sentences[:3])  # Adjust the number of sentences as needed

    # Calculate information retention
    information_retention_scores.append(len(summary) / len(section_text))

    # Calculate readability (average sentence length)
    readability_scores.append(
        sum(len(sent.split()) for sent in sorted_sentences) / len(sorted_sentences)
    )

    # Print the section's original heading, summary, and quality metrics
    print("Heading:", section)
    print("Original Length:", len(section_text))
    print("Summary:", summary)
    print("Summary Length:", len(summary))
    print("Information Retention Score:", information_retention_scores[-1])
    print("Readability Score:", readability_scores[-1])
    print("-" * 50)

# Calculate and print overall quality metrics
overall_information_retention = sum(information_retention_scores) / len(information_retention_scores)
overall_readability = sum(readability_scores) / len(readability_scores)

print("Overall Information Retention Score:", overall_information_retention)
print("Overall Readability Score:", overall_readability)