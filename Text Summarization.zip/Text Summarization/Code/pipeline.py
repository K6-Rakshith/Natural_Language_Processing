import requests
from bs4 import BeautifulSoup
import re
from nltk.tokenize import sent_tokenize, word_tokenize
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lsa import LsaSummarizer

# Define the URL of the Wikipedia page you want to scrape
url = "https://en.wikipedia.org/wiki/Alexander_the_Great"

# Send an HTTP GET request to the URL and retrieve the HTML content
response = requests.get(url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find all the headings and sub-headings (h1 to h6)
    headings = soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])

    # Find all the paragraphs containing text
    paragraphs = soup.find_all('p')

    # Create a dictionary to store the scraped data with headings as keys and content as values
    scraped_data = {}

    # Iterate through the headings and paragraphs and associate them
    current_heading = None
    for element in headings + paragraphs:
        if element.name.startswith('h'):  # Check if it's a heading
            current_heading = element.text.strip()
            scraped_data[current_heading] = []  # Initialize an empty list for content under this heading
        elif current_heading:
            scraped_data[current_heading].append(element.text.strip())

    # Text cleaning and tokenization
    cleaned_data = {}  # Dictionary to store cleaned and tokenized data

    for heading, content in scraped_data.items():
        cleaned_content = " ".join(content)  # Combine paragraphs into a single string
        # Clean the text by removing extra whitespace and special characters
        cleaned_content = re.sub(r'\s+', ' ', cleaned_content)
        cleaned_content = re.sub(r'[^\w\s]', '', cleaned_content)

        # Tokenize the cleaned content into sentences and words
        sentences = sent_tokenize(cleaned_content)  # Tokenize into sentences
        words = word_tokenize(cleaned_content)  # Tokenize into words

        cleaned_data[heading] = {
            "sentences": sentences,
            "words": words
        }

    # Text summarization using LsaSummarizer
    summarizer = LsaSummarizer()
    summarized_data = {}  # Dictionary to store summarized data

    for heading, data in cleaned_data.items():
        sentences = data["sentences"]
        # Create a parser and tokenize the sentences
        parser = PlaintextParser.from_string(" ".join(sentences), Tokenizer("english"))
        # Summarize the text (you can adjust the number of sentences in the summary)
        summary = summarizer(parser.document, sentences_count=2)
        # Convert the summary to a string
        summarized_text = " ".join([str(sentence) for sentence in summary])

        summarized_data[heading] = summarized_text

    # Print the generated summaries while retaining the structure of headings and sections
    for heading, summary in summarized_data.items():
        print(f"Heading: {heading}")
        print("Summary:")
        print(summary)
        print("\n" + "-"*40 + "\n")  # Add a separator between sections

else:
    print(f"Failed to retrieve the page. Status code: {response.status_code}")
