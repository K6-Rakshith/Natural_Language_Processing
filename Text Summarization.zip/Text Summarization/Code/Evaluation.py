#Information Retention (Cosine Similarity):
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Original content and summary (replace with your actual data)
original_text = "This is the original content."
summary = "This is the summary of the content."

# Create TF-IDF vectors for original text and summary
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform([original_text, summary])

# Calculate cosine similarity between TF-IDF vectors
cosine_sim = cosine_similarity(tfidf_matrix[0], tfidf_matrix[1])

# Information retention score
information_retention_score = cosine_sim[0][0]

print(f"Information Retention Score: {information_retention_score}")


#--------------------------------------------------------------------------------#

#Readability (Flesch-Kincaid Grade Level):
from textstat import flesch_kincaid_grade

# Summary text (replace with your actual summary)
summary = "This is the summary of the content."

# Calculate Flesch-Kincaid Grade Level
grade_level = flesch_kincaid_grade(summary)

print(f"Flesch-Kincaid Grade Level: {grade_level}")


#--------------------------------------------------------------------------------#

#Relevance (Word Frequency):
from collections import Counter
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import re

stopWords = set(stopwords.words('english'))

def getFrequencyScore(sentenceList, sentenceToCompareWith):
    # Tokenize the sentences
    words = word_tokenize(sentenceToCompareWith)
    # Remove stop words and special characters
    words = [word for word in words if word not in stopWords and re.match(r'[^\w\s]', word) is None]
    # Calculate word frequencies
    wordFrequencies = Counter(words)
    # Calculate the total frequency score
    totalFrequencyScore = 0
    for sentence in sentenceList:
        # Tokenize the sentences
        words = word_tokenize(sentence)
        # Remove stop words and special characters
        words = [word for word in words if word not in stopWords and re.match(r'[^\w\s]', word) is None]
        # Calculate word frequencies
        wordFrequencies = Counter(words)
        # Calculate the total frequency score
        for word in wordFrequencies:
            totalFrequencyScore += wordFrequencies[word]
    return totalFrequencyScore

# Original content and summary (replace with your actual data)
original_text = "This is the original content."
summary = "This is the summary of the content."

# Get the scores from both texts using function above
original_text_score = getFrequencyScore(original_text, summary)
summary_score = getFrequencyScore(summary, original_text)

# Check for zero division
if original_text_score == 0:
    relevance_score = 0  # Handle division by zero gracefully
else:
    # Calculate the relevance score
    relevance_score = summary_score / original_text_score

print(f"Relevance Score: {relevance_score}")



#--------------------------------------------------------------------------------#

#Coherence (Subjective Evaluation):
#Coherence is often evaluated subjectively. You can create a survey or questionnaire to collect feedback from human evaluators. There's no direct code implementation for subjective evaluation.


#--------------------------------------------------------------------------------#

#Length (Percentage Reduction):
# Original content and summary (replace with your actual data)
original_text = "This is the original content."
summary = "This is the summary of the content."

# Calculate the lengths of original text and summary
original_length = len(original_text)
summary_length = len(summary)

# Calculate percentage reduction
percentage_reduction = ((original_length - summary_length) / original_length) * 100

print(f"Percentage Reduction in Length: {percentage_reduction}%")


#--------------------------------------------------------------------------------#
